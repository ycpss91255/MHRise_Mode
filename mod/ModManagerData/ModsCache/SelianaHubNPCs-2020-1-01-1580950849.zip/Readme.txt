Monster Hunter: World - Put missing NPCs in Seliana Hub (Iceborne) v1.0
Mod by MHVuze

Adds the Lynian Expert (Tailraider Safari) and the Chief Ecologist (Monster Research) to the Seliana Hub.
Please refrain from speaking to these NPCs in the hub to advance story or big event DLC (like Witcher). I have linked all scripts but just avoid it to be save.
Tested and working with game build 399335. 

Use at your own risk! Play in offline mode if you fear a ban or whatever.

How-to:
0. Install Stracker's Loader
1. Move the nativePC folder from the downloaded archive to your install dir (i.e. D:\Steam\steamapps\common\Monster Hunter World)
2. Profit

To get rid of the mod, just remove the nativePC folder. Or, if you have other mods installed, remove the files of this mod to keep the other mods intact.

If you downloaded this mod from anywhere but NexusMods, be wary of malicious modifications.

Enjoy!

---

Donations are appreciated: https://streamlabs.com/mhvuze
Twitter: https://twitter.com/mhvuze